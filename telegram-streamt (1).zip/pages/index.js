export default function Home() {
  return (
    <main style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Tlive 🚀</h1>
      <p>Стриминг в Telegram с донатами и архивацией эфиров</p>
      <button
        style={{
          padding: "10px 20px",
          marginTop: "20px",
          fontSize: "16px",
          cursor: "pointer",
        }}
      >
        Начать стрим 🎥
      </button>
    </main>
  );
}
